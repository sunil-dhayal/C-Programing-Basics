#include <stdio.h> 
#include <stdlib.h> 
#include <time.h>
void ranfile(int min,int max,int n) 
{ 
    int i;
    srand(time(0)); 
    FILE *fin=fopen("1.txt","w");
	for(i=0;i<n;i++){ 
        int num=(rand()%(max-min+1))+min; 
        fprintf(fin,"%d ",num);
    }
    fclose(fin);
}
