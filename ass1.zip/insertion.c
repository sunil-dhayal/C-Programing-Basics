#include<stdio.h>
#include"header.h"
void insertion(int a[],int n){
	int temp,i,j;
	for(i=0;i<n;i++){
		j=i;
		while(j>0 && a[j-1]>a[j]){
			temp=a[j-1];
			a[j-1]=a[j];
			a[j]=temp;
			j--;
		}
	}
}
	
