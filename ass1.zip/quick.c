#include"header.h"
#include<stdio.h>
int n;
void swap(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
}
int partition (int arr[], int low, int high) 
{ 
    int pivot = arr[high]; 
    int pivotindex = low,j; 
  
    for(j = low; j <= high- 1; j++) 
    {
        if (arr[j] <= pivot) 
        {  
            swap(&arr[pivotindex], &arr[j]);
            pivotindex++;
        } 
    } 
    swap(&arr[pivotindex], &arr[high]); 
    return pivotindex; 
}
void quick(int arr[],int low, int high) 
{ int i;
    if (low < high) 
    {
        int pivotindex = partition(arr, low, high);
        quick(arr, low, pivotindex - 1);
        quick(arr, pivotindex + 1, high);
    }
} 

