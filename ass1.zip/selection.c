#include"header.h"
#include<stdio.h>
void selection(int a[],int n){
			int i,j,swap,in;
            for(i=0;i<n-1;i++){
                    in=i;
                    for(j=i+1;j<n;j++){
                        if(a[in]>a[j]){
                            in=j;
						}
              		}
                    swap=a[i];
                    a[i]=a[in];
                    a[in]=swap;
            }
}
