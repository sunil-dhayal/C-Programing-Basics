#include<stdlib.h>
#include<stdio.h>
#include"header.h"
#include<sys/time.h>
int main(){
	int n,min,max,k,i=0;
	printf("How many numbers you want to sort : ");
	scanf("%d",&n);
	int a[n],b[n],c[n],d[n],e[n];
	printf("Enter min value of numbers : ");
	scanf("%d",&min);
	printf("Enter max value of numbers : ");
	scanf("%d",&max);
	ranfile(min,max,n);
	FILE *fin=fopen("1.txt","r");
	while((fscanf(fin,"%d",&a[i]))!=EOF){
		i++;}
	for(k=0;k<n;k++)
		b[k]=a[k];
	
    long time_start,time_end;
    struct timeval tv;
    gettimeofday(&tv,NULL);                    time_start = (tv.tv_sec *1e+6) + tv.tv_usec;
    bubble(a,n);
    gettimeofday(&tv,NULL);                    time_end = (tv.tv_sec *1e+6) + tv.tv_usec;
    printf("bubble sort : %ld\n",time_end-time_start);
    
    for(k=0;k<n;k++)
		a[k]=b[k];
	gettimeofday(&tv,NULL);                    time_start = (tv.tv_sec *1e+6) + tv.tv_usec;
    insertion(a,n);
	gettimeofday(&tv,NULL);                    time_end = (tv.tv_sec *1e+6) + tv.tv_usec;
    printf("insertion sort : %ld\n",time_end-time_start);
    
    for(k=0;k<n;k++)
		a[k]=b[k];
    gettimeofday(&tv,NULL);                    time_start = (tv.tv_sec *1e+6) + tv.tv_usec;
    selection(a,n);
    gettimeofday(&tv,NULL);                    time_end = (tv.tv_sec *1e+6) + tv.tv_usec;
    printf("selection sort : %ld\n",time_end-time_start);
    
	for(k=0;k<n;k++)
		a[k]=b[k];
    gettimeofday(&tv,NULL);                    time_start = (tv.tv_sec *1e+6) + tv.tv_usec;
    merge(a,0,n-1);
    gettimeofday(&tv,NULL);                    time_end = (tv.tv_sec *1e+6) + tv.tv_usec;
    printf("merge sort : %ld\n",time_end-time_start);
    
    for(k=0;k<n;k++)
		a[k]=b[k];
    gettimeofday(&tv,NULL);                    time_start = (tv.tv_sec *1e+6) + tv.tv_usec;
    quick(a,0,n-1);
    gettimeofday(&tv,NULL);                    time_end = (tv.tv_sec *1e+6) + tv.tv_usec;
    printf("quick sort : %ld\n",time_end-time_start); 
}
