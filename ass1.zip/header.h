void bubble(int a[],int);
void insertion(int a[],int);
void selection(int a[],int );
void merge(int a[],int ,int );
void quick(int a[],int ,int );
void ranfile(int ,int ,int );
